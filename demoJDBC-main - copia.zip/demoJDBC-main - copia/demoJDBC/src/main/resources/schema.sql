CREATE TABLE IF NOT EXISTS Personas (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(255),
    apellidos VARCHAR(255),
    edad INT
    );
