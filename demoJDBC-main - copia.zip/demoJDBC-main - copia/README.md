# demoJDBC
Ejemplo de uso de JDBC con SpringBoot
